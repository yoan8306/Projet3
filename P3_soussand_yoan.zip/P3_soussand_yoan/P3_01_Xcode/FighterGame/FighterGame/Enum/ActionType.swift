//
//  ActionType.swift
//  FighterGame
//
//  Created by Yoan on 18/08/2021.
//

import Foundation

/// different role  of character can be
enum ActionType {
     case attacking, defending, doctor, healing
 }
