//
//  ActionEnum.swift
//  FighterGame
//
//  Created by Yoan on 18/08/2021.
//

import Foundation

/// for make action
enum ActionEnum {
    case attack, heal
}
